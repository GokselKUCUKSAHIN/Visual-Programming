package edu.erciyes.database;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.sql.*;
import java.util.Properties;

//This code needs a find_grade stored procedure in database to work
//You can find find_grade in javabook.sql
public class FindGradeCallable extends Application {
    private TextField tfId, tfCourseId;
    private Button btnFind;
    private Label lblStatus;
    private Connection connection;
    private CallableStatement callableStatement;

    @Override
    public void start(Stage primaryStage) throws Exception {
        GridPane root = new GridPane();

        tfId = new TextField();
        tfCourseId = new TextField();
        btnFind = new Button("Find");
        lblStatus = new Label();

        initializeDB();
        btnFind.setOnAction(e -> showGrade());

        root.add(new Label("Student Id: "), 0, 0);
        root.add(tfId, 1, 0);
        root.add(new Label("Course Id"), 0, 1);
        root.add(tfCourseId, 1, 1);
        root.add(btnFind, 1, 2);
        root.add(lblStatus, 1, 3);

        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(10, 10, 10, 10));
        root.setVgap(10);

        primaryStage.setScene(new Scene(root, 300, 300));
        primaryStage.setTitle("Find Grade");
        primaryStage.show();

    }

    @Override
    public void stop() throws Exception {
        // When the application finished, close the connection
        closeConnection(connection);
    }

    private void initializeDB() {
        //Set properties for database connection
        //Use your own user name and password
        String url = "jdbc:mysql://127.0.0.1:3306/javabook";
        Properties connectionProps = new Properties();
        connectionProps.setProperty("user", "root");
        connectionProps.setProperty("password", "MySQL123");
        connectionProps.setProperty("useSSL", "false");
        connectionProps.setProperty("serverTimezone", "UTC");
        connectionProps.setProperty("allowPublicKeyRetrieval", "true");

        //Prepare the callable query
        String callableQuery = "CALL find_grade(?,?)";

        //Create connection and statement objects
        try {
            connection = DriverManager.getConnection(url, connectionProps);
            callableStatement = connection.prepareCall(callableQuery);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void closeConnection(Connection connection) throws SQLException {
        if (connection != null) {
            System.out.println("Connection is Closing");
            connection.close();
        }

    }

    private void showGrade() {
        //Get the student number and course id from user interface
        String id = tfId.getText();
        String courseId = tfCourseId.getText();

        try {
            //Set parameters of the prepared statement
            callableStatement.setString(1,id);
            callableStatement.setString(2,courseId);
            //Execute query and store returned data in a result set
            ResultSet resultSet = callableStatement.executeQuery();
            while (resultSet.next())
                lblStatus.setText(resultSet.getString(1) + " " + resultSet.getString(2) + " " +
                        resultSet.getString(3) + " " + resultSet.getString(4));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
