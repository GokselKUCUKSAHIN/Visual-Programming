package edu.erciyes.database;

import java.util.Date;

public class Student {
    private String name;
    private String surname;
    private Date birthDate;
    private String department;

    public Student(String name, String surname, Date birthDate, String department) {
        this.name = name;
        this.surname = surname;
        this.birthDate = birthDate;
        this.department = department;
    }

    public String getName() {
        return name;
    }

    public Student setName(String name) {
        this.name = name;
        return this;
    }

    public String getSurname() {
        return surname;
    }

    public Student setSurname(String surname) {
        this.surname = surname;
        return this;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public Student setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
        return this;
    }

    public String getDepartment() {
        return department;
    }

    public Student setDepartment(String department) {
        this.department = department;
        return this;
    }
}
