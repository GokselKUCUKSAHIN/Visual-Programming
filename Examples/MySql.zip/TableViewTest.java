package edu.erciyes.database;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.*;

//TableViewTest sınıfı TableView kullanımını göstermektedir.
//Department sütunu kullanıcı tarafından değiştirilebilir durumdadır
//Tüm sütunların sütun başlıklarına tıklanılarak sıralanabildiğine dikkat ediniz
//TableView nesnesi altında bulunan textField tablodaki verileri filtrelemek için
//nasıl çalıştığını anlamak için filterData metodunu inceleyeniz

public class TableViewTest extends Application {
    private TableView<Student> table = new TableView();
    private ObservableList<Student> data = FXCollections.observableArrayList();
    private TextField filterField = new TextField();
    FilteredList<Student> filteredData;
    Connection conn;
    PreparedStatement preparedStatement;

    @Override
    public void start(Stage stage) throws Exception {
        VBox root = new VBox();

        initializeDB();
        table.setEditable(true);
        populateTable();

        filterField.textProperty().addListener((observable, oldValue, newValue) -> filterData(oldValue, newValue));

        TextField tfAddName = new TextField();
        tfAddName.setPromptText("First Name");
        TextField tfAddSurname = new TextField();
        tfAddSurname.setPromptText("Last Name");
        TextField tfBirthDate = new TextField();
        tfBirthDate.setPromptText("Birth Date");

        root.setSpacing(10);
        root.setPadding(new Insets(10, 10, 10, 10));
        root.getChildren().addAll(table, filterField);

        stage.setScene(new Scene(root, 400, 400));
        stage.setTitle("Table View Test");
        stage.show();
    }

    public void populateTable() {

        //Get data from database and add it to an ObservableList named data
        try {
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                data.add(new Student(rs.getString(1), rs.getString(2), rs.getDate(3), rs.getString(4)));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        //Create Table columns
        TableColumn<Student, String> colName = new TableColumn("First Name");
        colName.setCellValueFactory(new PropertyValueFactory<Student, String>("name"));
        colName.prefWidthProperty().bind(table.widthProperty().multiply(0.25));

        TableColumn<Student, String> colLastName = new TableColumn("Last Name");
        colLastName.setCellValueFactory(new PropertyValueFactory<Student, String>("surname"));
        colLastName.prefWidthProperty().bind(table.widthProperty().multiply(0.25));

        TableColumn<Student, String> colBirthDate = new TableColumn("Birth Date");
        colBirthDate.setCellValueFactory(new PropertyValueFactory<Student, String>("birthDate"));
        colBirthDate.prefWidthProperty().bind(table.widthProperty().multiply(0.25));

        //Make department column editable
        TableColumn<Student, String> colDepartment = new TableColumn("Department");
        colDepartment.setCellValueFactory(new PropertyValueFactory<Student, String>("department"));
        colDepartment.setCellFactory(TextFieldTableCell.<Student>forTableColumn());
        colDepartment.setOnEditCommit(
                (TableColumn.CellEditEvent<Student, String> t) -> {
                    ((Student) t.getTableView().getItems().get(t.getTablePosition().getRow())).setName(t.getNewValue());
                });
        colDepartment.prefWidthProperty().bind(table.widthProperty().multiply(0.25));

        //Add all columns to the table view
        table.getColumns().addAll(colName, colLastName, colBirthDate, colDepartment);
        //Load data to the table view
        table.setItems(data);
    }

    private void initializeDB() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://127.0.0.1:3306/javabook?serverTimezone = UTC";
            conn = DriverManager.getConnection(url, "root", "MySQL123");

            String query = "SELECT firstName, lastName, birthDate, department.name FROM student" +
                    " INNER JOIN department WHERE student.deptId = department.deptId";
            preparedStatement = conn.prepareStatement(query);

        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    //Filter data methods search rows of the TableView for the given String
    public void filterData(String oldValue, String newValue) {
        filteredData = new FilteredList<>(data, p -> true);
        filteredData.setPredicate(student -> {
            // If filter text is empty, display all persons.
            if (newValue == null || newValue.isEmpty()) {
                return true;
            }

            // Compare first name and last name of every person with filter text.
            String lowerCaseFilter = newValue.toLowerCase();

            if (student.getName().toLowerCase().contains(lowerCaseFilter)) {
                return true; // Filter matches first name.
            } else if (student.getSurname().toLowerCase().contains(lowerCaseFilter)) {
                return true; // Filter matches last name.
            }
            return false; // Does not match.
        });
        table.setItems(filteredData);

    }
}
