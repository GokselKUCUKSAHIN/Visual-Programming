package edu.erciyes.database;

import java.sql.*;

public class JDBCTest {
    public static void main(String[] args) throws SQLException {
        //This method prints the name and last name of each student in student table of javabook database
        //Please use your own username and password to access the database

        //Load the JDBC Driver
        //If you use a new version of MySQL connector you dont need this line
        //Class.forName("com.mysql.jdbc.Driver");

        //Establish a connection
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/javabook?serverTimezone=UTC", "root",   "1234" );

        //Create a statement
        Statement statement = connection.createStatement();

        //Execute the statement
        ResultSet resultSet = statement.executeQuery("SELECT firstName, lastName FROM student");

        //Iterate through the result and print student names
        while(resultSet.next()){
            System.out.println(resultSet.getString("firstName") + " " + resultSet.getString("lastName"));
        }
        //Close the connection
        connection.close();
    }
}
