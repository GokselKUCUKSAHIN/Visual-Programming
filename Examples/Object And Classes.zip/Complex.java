public class Complex {
    private double real;
    private double imaginary;
    private static int numberOfComplex;

    public Complex(double real, double imaginary) {
        this.real = real;
        this.imaginary = imaginary;
        numberOfComplex++;      //increase the number of Complex objects
    }

    public Complex() {  //no-arg constructor
        this(0.0, 0.0); //invoke the other constructor
    }

    public double getReal() {   //accessor method
        return this.real;
    }

    public void setReal(double real) {  //mutator method
        this.real = real;
    }

    public double getImaginary() {  //accessor method
        return this.imaginary;
    }

    public void setImaginary(double imaginary) {    //mutator method
        this.imaginary = imaginary;
    }

    public Complex plus(Complex other){     //add two complex number objects
        double sumReal = this.real + other.real;
        double sumImaginary = this.imaginary + other.imaginary;
        return new Complex(sumReal, sumImaginary);  //return sum as a new Complex object
    }

    public static int getNumberOfComplex() {    //static method
        return numberOfComplex;
    }

    @Override
    public String toString() {
        return this.real + " + " + this.imaginary + "i";
    }

    @Override
    public boolean equals(Object obj) {
        if(obj == null)
            return false;
        if(obj == this)
            return true;
        if(!(obj instanceof Complex))
            return false;
        Complex c = (Complex) obj;
        return this.real == c.real && this.imaginary == c.imaginary;
    }

    public static void main(String[] args) {
        //access static fields by using Class name such as Complex
        System.out.println("number of complex objects: " + Complex.getNumberOfComplex());
        Complex a = new Complex(10.0,15.0);
        Complex b = new Complex(2.5,5.5);
        Complex c = a.plus(b);
        System.out.println("c is " + c.toString());
        Complex d = new Complex(); //create object with no-arg constructor
        System.out.println("number of complex objects: " + Complex.getNumberOfComplex());

        //to check whether two objects are equal or not
        System.out.println("Is a and b equal: " + a.equals(b));
    }
}
