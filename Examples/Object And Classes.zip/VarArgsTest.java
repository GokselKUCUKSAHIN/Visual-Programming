import java.util.Arrays;

public class VarArgsTest {
    public static void main(String[] args) {
        System.out.println(sum());
        System.out.println(sum(1,15,20,100,89));
        System.out.println(min(12,25,48,2,44));

        //fun(1); // ambiguous invocation!
        // met(); // ambiguous invocation! 
        func(1);
        func(1,2);
        func(1,2,3,4,5,6,7,8,9);


    }
    public static int sum(int ... args){
        int sum = 0;
        for (int arg:args)
            sum += arg;
        return sum;
    }

    static int min(int firstArg, int... remainingArgs) { //GOOD WAY
        int min = firstArg;
        for (int arg : remainingArgs)
            if (arg < min)
                min = arg;
        return min;
    }

    static void fun(int ... v){
        System.out.println(Arrays.toString(v));
    }//ERROR: ambiguous invocation */
    static void fun(int v1, int ... v){
        System.out.println(Arrays.toString(v));
    }//ERROR: ambiguous invocation */

    static void met(int ... v){
        System.out.println(Arrays.toString(v));
    }//ERROR: ambiguous invocation */
    static void met(boolean ... v){
        System.out.println(Arrays.toString(v));
    }//ERROR: ambiguous invocation */

    static void func(int v1){
        //do something
    }  //GOOD WAY of overloading a method that takes a variable-length argument
    static void func(int v1, int v2){
        //do something
    }//GOOD WAY of overloading a method that takes a variable-length argument
    static void func(int v1, int v2, int ... vs){
        //do something
    }//GOOD WAY of overloading a method that takes a variable-length argument
}
