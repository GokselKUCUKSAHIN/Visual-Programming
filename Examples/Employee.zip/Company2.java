package edu.erciyes.employee;

import java.time.LocalDate;
import java.util.ArrayList;

public class Company2 {
    ArrayList<Employee2> employees;
    SalariedEmployee2[] salariedEmployees;
    HourlyEmployee2[] hourlyEmployees;

    public Company2() {
        employees = new ArrayList<Employee2>();
        employees.add(new SalariedEmployee2("Ada Lovelace", LocalDate.of(2000,10,10),50000));
        employees.add(new SalariedEmployee2("Linus Torvalds", LocalDate.of(1990,10,1), 45000));
        employees.add(new HourlyEmployee2("Steve Wozniak", LocalDate.of(2012,1,1)));
        employees.add(new HourlyEmployee2("Tim Berners-Lee", LocalDate.of(2002,2,2),30,150));


        salariedEmployees = new SalariedEmployee2[2];   //This array is for bad MonthlyPayroll method
        salariedEmployees[0] = new SalariedEmployee2("Ada Lovelace", LocalDate.of(2000,10,10),50000);
        salariedEmployees[1] = new SalariedEmployee2("Linus Torvalds", LocalDate.of(1990,10,1), 45000);

        hourlyEmployees = new HourlyEmployee2[2];   //This array is for bad MonthlyPayroll method
        hourlyEmployees[0] = new HourlyEmployee2("Steve Wozniak", LocalDate.of(2012,1,1));
        hourlyEmployees[1] = new HourlyEmployee2("Tim Berners-Lee", LocalDate.of(2002,2,2),30,150);
    }


    @Override
    public String toString() {
        //Polymorphic toString method
        //Employee supertype reference variable refers to its SubType objects (SalariedEmployee and HourlyEmployee)
        StringBuilder companyStr = new StringBuilder();
        for(Employee2 employee:employees){
            companyStr.append(employee.toString() + "\n");
        }
        return companyStr.toString();
    }

    public double badMonthlyPayroll(){
        //Bad way to calculate monthly payroll of the company
        //uses arrays for each type of employees
        double payroll = 0.0;
        for(HourlyEmployee2 hourlyEmployee:hourlyEmployees)
            payroll += hourlyEmployee.monthlyPay();
        for (SalariedEmployee2 salariedEmployee:salariedEmployees)
            payroll += salariedEmployee.monthlyPay();
        return payroll;
    }

    public double monthlyPayroll(){
        // This is the good way to calculate monthly payroll
        // However it doesn't work because Employee class doesn't have a monthlyPayroll method
        // We need an abstract method. And we will see it next 3rd version
        double payroll = 0.0;
        for(Employee2 employee:employees)
            payroll += employee.monthlyPay(); //ERROR!
        return payroll;
    }

    public static void main(String[] args) {
        Company2 comp = new Company2();
        System.out.println(comp.toString());;
    }
}
