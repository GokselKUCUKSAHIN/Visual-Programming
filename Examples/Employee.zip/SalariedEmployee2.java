package edu.erciyes.employee;

import java.time.LocalDate;

public class SalariedEmployee2 extends Employee2{
    private double annualSalary;
    private final static int MONTHS_PER_YEAR = 12;

    public SalariedEmployee2(String name, LocalDate hireDate, double annualSalary) {
        super(name, hireDate);
        this.annualSalary = annualSalary;
    }

    public double getAnnualSalary() {
        return annualSalary;
    }

    public void setAnnualSalary(double annualSalary) {
        this.annualSalary = annualSalary;
    }

    public double monthlyPay(){
        return annualSalary / MONTHS_PER_YEAR;
    }

    @Override
    public String toString() {
        return super.toString() + " Salary: " + annualSalary;
    }

}
