package edu.erciyes.employee;

import java.time.LocalDate;

public class HourlyEmployee2 extends Employee2 {
    private double hourlyWage;
    private double monthlyHours;

    public HourlyEmployee2(String name, LocalDate hireDate){
        this(name, hireDate, 20, 160);
    }

    public HourlyEmployee2(String name, LocalDate hireDate, double hourlyWage, double monthlyHours) {
        super(name, hireDate);
        this.hourlyWage = hourlyWage;
        this.monthlyHours = monthlyHours;
    }

    public double getHourlyWage() {
        return hourlyWage;
    }

    public void setHourlyWage(double hourlyWage) {
        this.hourlyWage = hourlyWage;
    }

    public double getMonthlyHours() {
        return monthlyHours;
    }

    public void setMonthlyHours(double monthlyHours) {
        this.monthlyHours = monthlyHours;
    }

    public double monthlyPay(){
        return monthlyHours * hourlyWage;
    }
    @Override
    public String toString() {
        return super.toString() + " Wage: " + hourlyWage + " Hours: " + monthlyHours;
    }
}
