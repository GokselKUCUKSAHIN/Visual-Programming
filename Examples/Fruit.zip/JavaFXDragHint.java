import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

/* This is a simple example that shows
how to handle with mouse-dragging over the nodes
*/

public class JavaFXDragHint extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        Pane root = new Pane();

        Circle circle1 = new Circle(150,200,100);
        Circle circle2 = new Circle(350,200,100);
        circle1.setFill(Color.BLUE);
        circle2.setFill(Color.RED);

        root.setOnDragDetected(e->root.startFullDrag());
        /* Full press-drag-release gesture can be started by calling startFullDrag()
        (on a node or scene) inside of a DRAG_DETECTED event handler.
        This call activates delivering of MouseDragEvents to the
        nodes that are under cursor during the dragging gesture.
        Please see Oracle Tutorial
        */

        circle1.setOnMouseDragEntered(e->circle1.setFill(Color.color(Math.random(), Math.random(), Math.random())));
        circle2.setOnMouseDragEntered(e->circle2.setFill(Color.color(Math.random(), Math.random(), Math.random())));

        root.getChildren().addAll(circle1,circle2);
        stage.setScene(new Scene(root,500,500));
        stage.show();
    }
}
