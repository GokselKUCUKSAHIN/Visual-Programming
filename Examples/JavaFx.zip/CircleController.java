import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class CircleController extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {

        Pane pane = new Pane();
        Circle circle = new Circle(100,100,50);
        circle.setFill(Color.BLUE);
        circle.setFocusTraversable(true);

        //make the circle draggable
        circle.setOnMouseDragged(e -> {
            circle.setCenterX(e.getX());
            circle.setCenterY(e.getY());});

        //move the circle if the user press arrow keys
        circle.setOnKeyPressed(e -> {
            switch (e.getCode()) {
                case DOWN: circle.setCenterY(circle.getCenterY() + 10); break;
                case UP:  circle.setCenterY(circle.getCenterY() - 10); break;
                case LEFT: circle.setCenterX(circle.getCenterX() - 10); break;
                case RIGHT: circle.setCenterX(circle.getCenterX() + 10); break;
            }
        });
        pane.getChildren().addAll(circle);

        //add buttons to control the size of circle
        Button btnShrink = new Button("Shrink");
        Button btnEnlarge = new Button("Enlarge");
        //Set FocusTraversable false for buttons so the circle can be focused
        btnEnlarge.setFocusTraversable(false);
        btnShrink.setFocusTraversable(false);

        //shrink or enlarge the circle by clicking corresponding button
        btnShrink.setOnAction(event -> circle.setRadius(circle.getRadius()-5));
        btnEnlarge.setOnAction(event -> circle.setRadius(circle.getRadius()+5));

        HBox btnBox = new HBox();
        btnBox.getChildren().addAll(btnShrink, btnEnlarge);
        btnBox.setAlignment(Pos.BOTTOM_CENTER);

        BorderPane root = new BorderPane();
        root.setCenter(pane);
        root.setBottom(btnBox);

        primaryStage.setScene(new Scene(root, 400,400));
        primaryStage.setTitle("Circle Controller");
        primaryStage.show();

        //request focus for circle so that circle can be moved by arrow keys
        circle.requestFocus();
    }
}
