import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;


public class ColorChanger extends Application {
    private Label lbl;
    @Override
    public void start(Stage primaryStage) throws Exception {
        VBox root = new VBox();
        root.setPadding(new Insets(10,10,10,10));
        root.setSpacing(10);
        Button btn = new Button("Random Color");
        lbl = new Label("BZ 214 Visual Programming");
        lbl.setFont(new Font(18));

        //Handle action event by using lambda expression
        btn.setOnAction((event -> {int red = (int) (Math.random()*256);
            int green = (int) (Math.random()*256);
            int blue = (int) (Math.random()*256);
            Color customColor = Color.rgb(red,green,blue);
            lbl.setTextFill(customColor);}));

        //Handle action event by using anonymous inner class
        /*
        btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                int red = (int) (Math.random()*256);
                int green = (int) (Math.random()*256);
                int blue = (int) (Math.random()*256);
                Color customColor = Color.rgb(red,green,blue);
                lbl.setTextFill(customColor);
            }
        });*/

        //Handle action event by using inner class
        //ClickHandler handler = new ClickHandler();
        //btn.setOnAction(handler);

        root.getChildren().addAll(lbl, btn);
        Scene scene = new Scene(root, 300, 100);
        primaryStage.setTitle("Color Changer"); // Set the stage title
        primaryStage.setScene(scene); // Place the scene in the stage
        primaryStage.show(); // Display the stage
    }

    //Inner class to handle button click
    /*class ClickHandler implements EventHandler<ActionEvent>{
    @Override
    public void handle(ActionEvent event) {
        int red = (int) (Math.random()*256);
        int green = (int) (Math.random()*256);
        int blue = (int) (Math.random()*256);
        Color customColor = Color.rgb(red,green,blue);
        lbl.setTextFill(customColor);
    }
    }*/
}
