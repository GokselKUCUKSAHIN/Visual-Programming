
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.stage.Stage;

public class JavaFXShape extends Application{
    @Override
    public void start(Stage stage) throws Exception {
        Pane root = new Pane();

        //Draws a rectangle
        Rectangle r1 = new Rectangle(10,10,100,50);
        r1.setFill(Color.WHITE);
        r1.setStroke(Color.RED);

        //Draws a rounded rectangle
        Rectangle r2 = new Rectangle(10,80,100,50);
        r2.setFill(Color.YELLOW);
        r2.setStroke(Color.BLUE);
        r2.setArcHeight(30);
        r2.setArcWidth(30);

        //Draws a ellipse and rotates it
        Ellipse e1 = new Ellipse(60,180,50,25);
        e1.setFill(Color.GREEN);
        e1.setStroke(Color.BROWN);
        e1.setRotate(45.0);

        //Draws a filled arc
        Arc a1 = new Arc(200,60,100,50,0,90);
        a1.setType(ArcType.ROUND);
        a1.setFill(Color.RED);

        //Draws a open arc
        Arc a2 = new Arc(200,140,100,50,45,90);
        a2.setType(ArcType.OPEN);
        a2.setFill(Color.TRANSPARENT);
        a2.setStroke(Color.ORANGE);

        //Draws a triangle by using polygon
        Polygon p1 = new Polygon();
        p1.getPoints().addAll(200.0, 180.0, 250.0, 180.0, 225.0, 220.0);
        p1.setStroke(Color.BLUE);
        p1.setFill(Color.TRANSPARENT);
        p1.setStrokeWidth(5);

        root.getChildren().addAll(r1,r2, e1, a1, a2, p1);
        stage.setScene(new Scene(root,400,400));
        stage.setTitle("JavaFX Shapes");
        stage.show();
    }
}
