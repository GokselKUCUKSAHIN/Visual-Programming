import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;

public class ClockAnimation extends Application{
    @Override
    public void start(Stage primaryStage) throws Exception {
        ClockPane clock = new ClockPane();
        Label lblTime = new Label(clock.getTimeString());
        lblTime.setFont(new Font(16));

        // Create a handler that sets current time for animation
        EventHandler<ActionEvent> handler = e -> {
            clock.setCurrentTime();
            lblTime.setText(clock.getTimeString());
        };

        // Create animation for running the clock
        Timeline animation = new Timeline(new KeyFrame(Duration.millis(1000), handler));
        animation.setCycleCount(Timeline.INDEFINITE);
        animation.play();   //start the animation

        // Create root node and scene and place them in the stage
        BorderPane root = new BorderPane();
        root.setCenter(clock);
        root.setBottom(lblTime);
        BorderPane.setAlignment(lblTime, Pos.BOTTOM_CENTER);
        primaryStage.setScene(new Scene(root, 400,400));
        primaryStage.setTitle("Clock Animation");
        primaryStage.show();
    }
}
