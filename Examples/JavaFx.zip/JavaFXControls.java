import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;


public class JavaFXControls extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
		
		Text text = new Text(50, 50, "BZ214 Visual Programming");
        Pane paneText = new Pane();
        paneText.getChildren().add(text);
		
		//Add buttons that moves the text 
		HBox paneButtons = new HBox(20);
        Button btRight = new Button("Right", new ImageView("file:image/left.png"));
        Button btLeft = new Button("Left", new ImageView("file:image/right.png"));
        paneButtons.getChildren().addAll(btLeft, btRight);
        paneButtons.setAlignment(Pos.CENTER);
        paneButtons.setStyle("-fx-border-color: green");

        btLeft.setOnAction(e -> text.setX(text.getX() - 10));
        btRight.setOnAction(e -> text.setX(text.getX() + 10));

		//Add CheckBoxes that makes the text bold and/or italic
        VBox paneCheckBoxes = new VBox(20);
        paneCheckBoxes.setPadding(new Insets(5, 5, 5, 5));
        paneCheckBoxes.setStyle("-fx-border-color: green");
        CheckBox chkBold = new CheckBox("Bold");
        CheckBox chkItalic = new CheckBox("Italic");
        paneCheckBoxes.getChildren().addAll(chkBold, chkItalic);

        EventHandler<ActionEvent> handler = e -> {
            if (chkBold.isSelected() && chkItalic.isSelected())
                text.setFont(Font.font("Times New Roman",
                        FontWeight.BOLD, FontPosture.ITALIC, 20)); // Both check boxes checked
            else if (chkBold.isSelected())
                text.setFont(Font.font("Times New Roman",
                        FontWeight.BOLD, FontPosture.REGULAR, 20)); // The Bold check box checked
            else if (chkItalic.isSelected())
                text.setFont(Font.font("Times New Roman",
                        FontWeight.NORMAL, FontPosture.ITALIC, 20)); // The Italic check box checked
            else
                text.setFont(Font.font("Times New Roman",
                        FontWeight.NORMAL, FontPosture.REGULAR, 20)); // Both check boxes unchecked
        };

        chkBold.setOnAction(handler);
        chkItalic.setOnAction(handler);

		//Add RadioButtons that changes the color of text
        VBox paneRadioButtons = new VBox(20);
        paneRadioButtons.setPadding(new Insets(5, 5, 5, 5));
        paneRadioButtons.setStyle("-fx-border-width: 2px; -fx-border-color: green");

        RadioButton rbRed = new RadioButton("Red");
        RadioButton rbGreen = new RadioButton("Green");
        RadioButton rbBlue = new RadioButton("Blue");
        paneRadioButtons.getChildren().addAll(rbRed, rbGreen, rbBlue);

        ToggleGroup group = new ToggleGroup();
        rbRed.setToggleGroup(group);
        rbGreen.setToggleGroup(group);
        rbBlue.setToggleGroup(group);

        rbRed.setOnAction(e -> {
            if (rbRed.isSelected())
                text.setFill(Color.RED);
        });

        rbGreen.setOnAction(e -> {
            if (rbGreen.isSelected())
                text.setFill(Color.GREEN);
        });

        rbBlue.setOnAction(e -> {
            if (rbBlue.isSelected())
                text.setFill(Color.BLUE);
        });
        
		//Add a TextField that enables the user to change the text
        BorderPane paneTextField = new BorderPane();
        paneTextField.setPadding(new Insets(5, 5, 5, 5));
        paneTextField.setStyle("-fx-border-color: green");
        paneTextField.setLeft(new Label("Enter a new text: "));
        TextField tf = new TextField();
        tf.setAlignment(Pos.BOTTOM_RIGHT);
        paneTextField.setCenter(tf);       

        tf.setOnAction(e -> text.setText(tf.getText()));

		//Add all panes to the root node
	    BorderPane root = new BorderPane();
        root.setBottom(paneButtons);
        root.setCenter(paneText);
		root.setRight(paneCheckBoxes);
		root.setLeft(paneRadioButtons);
		root.setTop(paneTextField);
		
        Scene scene = new Scene(root, 450, 200);
        primaryStage.setTitle("JavaFX Controls Example"); // Set the stage title
        primaryStage.setScene(scene); // Place the scene in the stage
        primaryStage.show(); // Display the stage
    }
}
