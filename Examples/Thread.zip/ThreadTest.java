package edu.erciyes.concurrency;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

//This example show how to create threads by using Thread class and Thread Poools (ExecutorService)
//Please see ThreadTest and ThreadPoolTest classes

public class ThreadTest {
    public static void main(String[] args) {
        // Create tasks
        Runnable printHello = new Hello(100);
        Runnable printGoodbye = new Goodbye(100);

        // Create threads
        Thread threadHello = new Thread(printHello);
        Thread threadGoodbye = new Thread(printGoodbye);

        // Start threads
        threadHello.start();
        threadGoodbye.start();
    }
}

class ThreadPoolTest {
    public static void main(String[] args) {
        // Create a fixed thread pool with maximum two threads
        ExecutorService executor = Executors.newFixedThreadPool(2);

        // Submit runnable tasks to the executor
        executor.execute(new Hello(100));
        executor.execute(new Goodbye(100));

        // Shut down the executor
        executor.shutdown();
    }
}

// The task for printing Hello in given times
class Hello implements Runnable {
    private int times;  //The number of times to repeat

    //Construct a task
    public Hello(int times) {
        this.times = times;
    }

    //Override the run() method to tell the system what the task to perform
    @Override
    public void run() {
        try{
            for (int i = 0; i < times; i++) {
                System.out.println("Hello " + i);
                Thread.sleep(100);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

// The task for printing Goodbye in given times
class Goodbye implements Runnable {
    private int times;

    public Goodbye(int times) {
        this.times = times;
    }

    @Override
    public void run() {
        Thread helloThread = new Thread(new Hello(100));
        helloThread.start();
        try {
            for (int i = 0; i < times; i++) {
                System.out.println("Goodbye " + i);
                helloThread.join();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}
