package edu.erciyes.concurrency;

public class ThreadClassMethodsTest {
    public static void main(String[] args) {
        Thread helloThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    for (int i = 0; i < 100; i++) {
                        System.out.println("Hello " + i);
                        //sleep for the 100 millisecond
                        Thread.sleep(100);
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        Thread goodbyeThread = new Thread(()->{
            try {
                //wait for the helloThread to end or 1 second
                helloThread.join(1000);
                for (int i = 0; i < 100; i++) {
                    System.out.println("Goodbye " + i);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        });

        helloThread.start();
        goodbyeThread.start();
    }
}
