import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegExTest {
    public static void main(String[] args) {
        String s = "in 1991 Oak released\tin 1996 it renamed as java, "+
                "JDK 1.0 released in 1996";

        System.out.println(s.replaceAll("in","at"));
        System.out.println(s.replaceAll("^in","at"));
        System.out.println(s.replaceAll("1996$","YYYY"));
        System.out.println(s.replaceAll("[in]","Y"));
        System.out.println(s.replaceAll("[Jj]ava","Java"));
        System.out.println(s.replaceAll("[0-9]","Y"));
        System.out.println(s.replaceAll("\\d","Y"));

        String[] parts = s.split("\\s");
        System.out.println(Arrays.toString(parts));

        String text = "A sailor went to sea sea sea to see what could see see seee";
        System.out.println(text.replaceAll("se+","YYY"));
        System.out.println(text.replaceAll("se{2}","YYY"));
        System.out.println(text.replaceAll("se{2,}","YYY"));
        System.out.println(text.replaceAll("se[ae]+","YYY"));  

        StringBuilder html = new StringBuilder("<h1>My heading</h1>");
        html.append("<h2>Sub heading</h2>");
        html.append("<p>This is a paragraph</p>");
        html.append("<h2>Summary</h2>");
        html.append("<p>Here is the summary</p>");
        System.out.println(html.toString());

        String h2Pattern = "<h2>";
        Pattern pattern = Pattern.compile(h2Pattern);
        Matcher matcher = pattern.matcher(html);
        System.out.println(matcher.matches());

        matcher.reset();
        int count = 0;
        while (matcher.find()){
            count++;
            System.out.println(count +": "+ matcher.start()+" "+ matcher.end());
        }

        //String h2GroupPattern = "(<h2>.*</h2>)";//greedy quantifier
        //String h2GroupPattern = "(<h2>.*?</h2>)"; //lazy quantifier
        String h2GroupPattern = "(<h2>)(.*?)(</h2>)";
        Pattern groupPattern = Pattern.compile(h2GroupPattern);
        Matcher groupMatcher = groupPattern.matcher(html);

        while(groupMatcher.find()){
            System.out.println(groupMatcher.group(2));
        }
    }
}
