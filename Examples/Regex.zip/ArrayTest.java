
import java.util.Arrays;

public class ArrayTest {
    public static void main(String[] args){
        int key = 21;
        //int[] list = {3, 5, 6, 12, 21, 22, 35, 42};
        int[] list = {34, 21, 2, 33, 15, 16, 4, 9, 23};

	    //Arrays.sort(list); //you can use static sort method
        int[] result = selectionSort(list);
        System.out.println(Arrays.toString(result));
	
	    //int index = Arrays.binarySearch(result, key);
        int index = binarySearch(result, key);
        System.out.println("index of " + key + " is: " + index);
    }

    public static int[] selectionSort(int[] list){
        for(int i = 0; i < list.length-1; i++){
            int currentMin = list[i];
            int currentMinIndex = i;
            for(int j = i + 1; j < list.length; j++){ //select
                if(currentMin > list[j]){
                    currentMin = list[j];
                    currentMinIndex = j;
                }
            }
            if(currentMinIndex != i) {          //swap
                list[currentMinIndex] = list[i];
                list[i] = currentMin;
            }
        }
        return list;
    }

    public static int binarySearch(int[] list, int key){
        int low = 0;
        int high = list.length -1;
        while (high >= low){
            int mid = (high + low)/2;
            if(key < list[mid])
                high = mid -1;
            else if(key == list[mid])
                return mid;
            else
                low = mid + 1;
        }
        return -low-1;
    }
}
