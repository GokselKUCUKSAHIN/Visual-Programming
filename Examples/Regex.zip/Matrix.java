
public class Matrix {

    //matrix multiplication
    public static double[][] multiply(double[][] a, double[][] b) {
        int x1 = a.length;
        int y1 = a[0].length;
        int x2 = b.length;
        int y2 = b[0].length;
        if (y1 != x2)   //If matrix sizes are not suitable to multiply throw exception
            throw new RuntimeException("Illegal matrix dimensions.");
        double[][] c = new double[x1][y2];
        for (int i = 0; i < x1; i++)
            for (int j = 0; j < y2; j++)
                for (int k = 0; k < y1; k++)
                    c[i][j] += a[i][k] * b[k][j];
        return c;
    }

    // matrix-vector multiplication
    public static double[] multiply(double[][] a, double[] u) {
        int x = a.length;
        int y = a[0].length;
        if (u.length != y)
            throw new RuntimeException("Illegal matrix dimensions.");
        double[] v = new double[x];
        for (int i = 0; i < x; i++)
            for (int j = 0; j < y; j++)
                v[i] += a[i][j] * u[j];
        return v;
    }

    // return string representation of given matrix
    public static String toString(double[][] a){
        StringBuilder sb = new StringBuilder();
        int numOfRows = a.length;
        int numOfCols = a[0].length;
        for(int i = 0; i < numOfRows; i++){
            for (int j = 0; j < numOfCols ; j++)
                sb.append(a[i][j] + " ");
            sb.append("\n");
        }
        return sb.toString();
    }

    public static void main(String[] args) {    //to test Matrix class
        double[][] a = { { 4.00, 3.00 }, { 2.00, 1.00 } };
        double[][] b = { { -0.500, 1.500 }, { 1.000, -2.0000 } };
        double[][] result;

        try{
            result = Matrix.multiply(a, b);
            System.out.println(Matrix.toString(result));
        }catch (Exception e){
            System.out.println("Try again");
        }

    }
}
