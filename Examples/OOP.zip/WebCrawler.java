

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WebCrawler {
    public static void main(String[] args) {
        //specify the starting URL
        String startingURL = "https://www.erciyes.edu.tr/";
        crawl(startingURL); //start crawling
    }
    public static void crawl(String startingURL){
        ArrayList<String> pendingURLs = new ArrayList<>();      //list of the pending URLs
        ArrayList<String> traversedURLs = new ArrayList<>();    //list of the traversed URLs
        pendingURLs.add(startingURL);   //add starting URl to the pending list
        while(!pendingURLs.isEmpty() && traversedURLs.size() < 1000){
            String urlString = pendingURLs.remove(0);       //get the top element of the pending array
            traversedURLs.add(urlString);                     //add it to the list of traversed URLs
            System.out.println("Crawl: " + urlString);
            for (String s:getSubURLs(urlString)){             //get a list of URLs by calling getSubURLs method
                if(!pendingURLs.contains(s) && !traversedURLs.contains(s))
                    pendingURLs.add(s);     //if the URL is not in both lists add it to the list of pending URLs
            }
        }
    }
    public static ArrayList<String> getSubURLs(String urlStr){
        ArrayList<String> list = new ArrayList<>();             //create a list for URLs in the web page
        String regex = "((http|https)://(\\w+\\.)+(edu|com|org|net|gov)(\\.tr)?)";  //define a regex matches with URLs
        Pattern pattern = Pattern.compile(regex);       //create pattern object
        Matcher matcher;
        try {
            URL url = new URL(urlStr);      //create URL object
            Scanner scanner = new Scanner(url.openStream());    //create a scanner object to read from URL
            while (scanner.hasNext()){      //if the scanner has next line
             String line = scanner.nextLine();  //read the next line
             matcher = pattern.matcher(line);   //check for the URLs that matches defined RegEx
             while (matcher.find())             //if it matches
                 list.add(matcher.group());     //add to the list
            }
        } catch (MalformedURLException e) {
            //e.printStackTrace();
        } catch (IOException e) {
            //e.printStackTrace();
        }
        return list;
    }

}
