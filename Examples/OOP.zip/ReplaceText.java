import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class ReplaceText {
// This is a example to show how to use Scanner and PrinterWriter classes
// and how to use try-with-resources
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter: sourceFile targetFile oldStr newStr");
        String input = scanner.nextLine();      // input.txt output.txt text new
        String[] inputs = input.split(" ");    //split input string into sub strings
        if (inputs.length != 4){        //check the number of arguments
            System.out.println("Enter: sourceFile targetFile oldStr newStr");
            System.exit(1);
        }
        try {
            //replaceText(inputs);
            replaceTextWithAutoClose(inputs);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void replaceText(String[] input)  throws FileNotFoundException{
        File sourceFile = new File(input[0]);
        File targetFile = new File(input[1]);
        if(!sourceFile.exists())
            System.out.println("Source file does not exist");
        if(targetFile.exists()) {
            System.out.println("Target file already exists");
            targetFile.delete();
        }
        Scanner scanner = new Scanner(sourceFile);          // create Scanner object
        PrintWriter writer = new PrintWriter(targetFile);   //create PrintWriter object
        String line, newLine;
        while (scanner.hasNext()){          //has next line
            line = scanner.nextLine();      //read line
            newLine = line.replaceAll(input[2], input[3]);  //modify line
            writer.println(newLine);        //write line to the target file
        }
        scanner.close();        //close Scanner object
        writer.close();         //close PrintWriter object
    }

    public static void replaceTextWithAutoClose(String[] input) throws FileNotFoundException{
        File sourceFile = new File(input[0]);
        File targetFile = new File(input[1]);
        if(!sourceFile.exists())
            System.out.println("Source file does not exist");
        if(targetFile.exists())
            System.out.println("Target file already exists");

        //try-with resources
        try(Scanner scanner = new Scanner(sourceFile);          // create Scanner object
            PrintWriter writer = new PrintWriter(targetFile)){  //create PrintWriter object
            String line, newLine;
            while(scanner.hasNext()){           //has next line
                line = scanner.nextLine();      //read line
                newLine = line.replaceAll(input[2], input[3]);  //modify line
                writer.println(newLine);        //write line to the target file
            }
        }// Scanner and PrintWriter objects closed automatically
    }

}
