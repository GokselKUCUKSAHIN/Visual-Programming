package edu.erciyes.employee;

import java.time.LocalDate;

public class SalariedEmployee3 extends Employee3{
    private double annualSalary;
    private final static int MONTHS_PER_YEAR = 12;

    public SalariedEmployee3(String name, LocalDate hireDate, double annualSalary) {
        super(name, hireDate);
        Utils3.disallowZeroesAndNegatives(annualSalary);
        this.annualSalary = annualSalary;
    }

    public double getAnnualSalary() {
        return annualSalary;
    }

    public void setAnnualSalary(double annualSalary) {
        this.annualSalary = annualSalary;
    }

    public double monthlyPay(){
        return annualSalary / MONTHS_PER_YEAR;
    }

    @Override
    public String toString() {
        return super.toString() + " Salary: " + annualSalary;
    }

}
