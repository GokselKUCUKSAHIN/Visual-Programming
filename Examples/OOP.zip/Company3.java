package edu.erciyes.employee;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collections;

public class Company3 {
    ArrayList<Employee3> employees;

    public Company3() {
        employees = new ArrayList<Employee3>();
        employees.add(new SalariedEmployee3("Ada Lovelace", LocalDate.of(2000,10,10),50000));
        employees.add(new SalariedEmployee3("Linus Torvalds", LocalDate.of(1990,10,1), 45000));
        employees.add(new HourlyEmployee3("Steve Wozniak", LocalDate.of(2012,1,1)));
        employees.add(new HourlyEmployee3("Tim Berners-Lee", LocalDate.of(2002,2,2),30,150));
    }

    public Company3(String fileName) {
        this.employees = initFromFile(fileName);
    }

    public ArrayList<Employee3> getEmployees() {
        return employees;
    }

    public String toString() {
        //Polymorphic toString method
        //Employee supertype reference variable refers to its SubType objects (SalariedEmployee and HourlyEmployee)
        StringBuilder companyStr = new StringBuilder();
        for(Employee3 employee:employees){
            companyStr.append(employee.toString() + "\n");
        }
        return companyStr.toString();
    }

    public double monthlyPayroll(){
        // This is the good way to calculate monthly payroll
        double payroll = 0.0;
        for(Employee3 employee:employees)
            payroll += employee.monthlyPay();
        return payroll;
    }

    public void sort(){
        // sort method sorts employees due to compareTo method of Employee3 class
        Collections.sort(employees);
    }

    private ArrayList<Employee3> initFromFile(String fileName){ //Reads given data file and
        ArrayList<Employee3> emps = new ArrayList<>();
        File file = new File(fileName);
        try {
            FileReader fileReader = new FileReader(file); //FileReader class is designed to read from text files
            BufferedReader reader = new BufferedReader(fileReader); //BufferedReader uses FileReader object to read the data from the file
            String line = reader.readLine();    // buffered first line in data file
            while (line != null){           //Also you can make this as:(line = br.readLine()) != null)
                String[] values = line.split(",");  //Split lines based on "," since our data is in CSV format
                if(values[0].trim().equalsIgnoreCase("SalariedEmployee"))
                    emps.add(createSalariedEmployee(values));      //pass values to method to get new salaried employee
                else if(values[0].trim().equalsIgnoreCase("HourlyEmployee"))
                    emps.add(createHourlyEmployee(values));        //pass values to method to get new hourly employee
                else
                    System.out.println("Line is not suitable to produce employee");
                line = reader.readLine();       //read the next line in data file
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }catch (RuntimeException e){
            e.printStackTrace();
        }
        return emps;
    }
    private SalariedEmployee3 createSalariedEmployee(String[] values) throws DateTimeParseException, NumberFormatException{
        String name = values[1].trim();
        LocalDate hireDate = LocalDate.parse(values[2].trim());
        double annualSalary = Double.parseDouble(values[3].trim()); //This can throws DateTimeParseException we declare it
        return new SalariedEmployee3(name, hireDate, annualSalary); //This can throws NumberFormatException we declare it
    }
    private HourlyEmployee3 createHourlyEmployee(String[] values) throws DateTimeParseException, NumberFormatException{
        String name = values[1].trim();
        LocalDate hireDate = LocalDate.parse(values[2].trim());//This can throws DateTimeParseException we declare it
        double hourlyWage = Double.parseDouble(values[3].trim());//This can throws NumberFormatException we declare it
        double monthlyHours = Double.parseDouble(values[4].trim());//This can throws NumberFormatException we declare it
        return new HourlyEmployee3(name, hireDate, hourlyWage, monthlyHours);
    }

    public static void main(String[] args) {
        Company3 company = new Company3("Employee.data");
        company.sort();
        System.out.println(company.toString());
        System.out.println("Payroll: " + company.monthlyPayroll());
    }

}
