package edu.erciyes.employee;

import java.time.LocalDate;

public abstract class Employee3 implements Comparable<Employee3> {
    private String name;
    private LocalDate hireDate;

    public Employee3(String name, LocalDate hireDate) {
        Utils3.disallowNullArguments(name, hireDate);
        this.name = name;
        this.hireDate = hireDate;
    }

    public String getName() {
        return name;
    }

    public LocalDate getHireDate() {
        return hireDate;
    }

    @Override
    public String toString() {
        return "Name: " + name + " Date: " + hireDate;
    }

    //We want to make monthlyPay method polymorphic
    //Since we don't have a general definition for monthlyPay we make it abstract
    public abstract double monthlyPay();

    @Override
    public int compareTo(Employee3 emp) {
        //Compare employees due to their hire dates
        return this.hireDate.compareTo(emp.hireDate);
    }
}
