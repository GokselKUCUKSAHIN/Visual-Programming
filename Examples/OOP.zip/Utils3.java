package edu.erciyes.employee;

public class Utils3 {

      static void disallowNullArguments(Object ... args) {
        for (Object arg: args) {
            if (arg == null) {
                String msg = "Null arguments not allowed.";
                throw new IllegalArgumentException(msg);
            }
        }
    }

    static void disallowZeroesAndNegatives(double ... args) {
        for (double arg: args) {
            if (arg <= 0.0) {
                String msg = "Zero or Negative Arguments";
                throw new IllegalArgumentException(msg);
            }
        }
    }

}
