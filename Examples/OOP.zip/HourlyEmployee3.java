package edu.erciyes.employee;

import java.time.LocalDate;

public class HourlyEmployee3 extends Employee3{
    private double hourlyWage;
    private double monthlyHours;

    public HourlyEmployee3(String name, LocalDate hireDate){
        this(name, hireDate, 20, 160);
    }

    public HourlyEmployee3(String name, LocalDate hireDate, double hourlyWage, double monthlyHours) {
        super(name, hireDate);
        Utils3.disallowZeroesAndNegatives(hourlyWage,monthlyHours);
        this.hourlyWage = hourlyWage;
        this.monthlyHours = monthlyHours;
    }

    public double getHourlyWage() {
        return hourlyWage;
    }

    public void setHourlyWage(double hourlyWage) {
        this.hourlyWage = hourlyWage;
    }

    public double getMonthlyHours() {
        return monthlyHours;
    }

    public void setMonthlyHours(double monthlyHours) {
        this.monthlyHours = monthlyHours;
    }

    public double monthlyPay(){
        return monthlyHours * hourlyWage;
    }
    @Override
    public String toString() {
        return super.toString() + " Wage: " + hourlyWage + " Hours: " + monthlyHours;
    }
}
