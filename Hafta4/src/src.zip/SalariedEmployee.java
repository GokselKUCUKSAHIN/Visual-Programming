import edu.erciyes.employee.Employee;

import java.time.LocalDate;

public class SalariedEmployee extends Employee
{
    private double annualSalary;
    private static final int MONTH_PER_YEAR = 12;
    public SalariedEmployee(String name, LocalDate hireDate,double annualSalary)
    {
        super(name,hireDate);
        diasallowZerosAndNegatives(annualSalary);
        this.annualSalary = annualSalary;
    }
    public void diasallowZerosAndNegatives(double ... args)
    {
        for (double arg: args)
        {
            if(arg <= 0)
            {
                throw new IllegalArgumentException("Gecersiz deger!");
            }
        }
    }
    public double getAnnualSalary()
    {
        return this.annualSalary;
    }
    public double monthlyPay()
    {
        return getAnnualSalary() / (double) MONTH_PER_YEAR;
    }
    @Override
    public String toString()
    {
        return super.toString() + " Monthly Pay: " + monthlyPay();
    }
}
