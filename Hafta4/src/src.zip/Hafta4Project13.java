import edu.erciyes.employee.Employee;
import edu.erciyes.employee.HourlyEmployee;

import java.time.LocalDate;

public class Hafta4Project13
{

    public static void main(String[] args)
    {
        HourlyEmployee ali = new HourlyEmployee("Ali Cengiz", LocalDate.of(2010,5,18));
        System.out.println(ali.toString());
        //new Employee(null,null);
        
    }
}
